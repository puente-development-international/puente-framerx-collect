import * as React from "react"
import { PropertyControls, ControlType, addPropertyControls } from "framer"
import * as FeatherIcons from "react-feather"

export function Icon(props) {
    const { icon, width, height, color, set, fontLoaded } = props
    let name = `${icon.toLowerCase()}`
    let faName = "fa" + `${icon.charAt(0).toUpperCase()}` + `${icon.substr(1)}`

    name = icon
        .split("-")
        .map(piece => piece.charAt(0).toUpperCase() + piece.slice(1))
        .join("")

    const TagName = FeatherIcons[name]
    if (!TagName) return null
    return <TagName icon={name} width={width} height={height} color={color} />

    return null
}

Icon.defaultProps = {
    icon: "flag",
    width: 24,
    height: 24,
    color: "#000",
}

addPropertyControls(Icon, {
    icon: { type: ControlType.String, title: "Icon" },
    color: { type: ControlType.Color, title: "Color" },
})
