import * as React from "react"
import { PropertyControls, ControlType, addPropertyControls } from "framer"
import MaterialIcon from "@material-ui/core/Icon"
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome"
import * as Icons from "@fortawesome/free-regular-svg-icons"
import * as FeatherIcons from "react-feather"
import * as WebFont from "webfontloader"

// Define type of property
interface Props {
    icon: string
    width: number
    height: number
    color: string
    set: "feather" | "material" | "fontawesome"
    fontLoaded: boolean
}

const materialIconsFont = "Material+Icons"
let materialFontIsLoaded = false

export function Icon(props: Props) {
    return (
        <div>
            <RenderIcon {...props} />
        </div>
    )
}

function RenderIcon(props: Props) {
    const { icon, width, height, color, set, fontLoaded } = props
    let name = `${icon.toLowerCase()}`
    let faName = "fa" + `${icon.charAt(0).toUpperCase()}` + `${icon.substr(1)}`

    name = icon
        .split("-")
        .map(piece => piece.charAt(0).toUpperCase() + piece.slice(1))
        .join("")

    const TagName = FeatherIcons[name]
    if (!TagName) return null
    return <TagName icon={name} width={width} height={height} color={color} />

    return null
}

Icon.defaultProps = {
    icon: "flag",
    width: 24,
    height: 24,
    color: "#000",
} as Props

addPropertyControls(Icon, {
    icon: { type: ControlType.String, title: "Icon" },
    color: { type: ControlType.Color, title: "Color" },
})
