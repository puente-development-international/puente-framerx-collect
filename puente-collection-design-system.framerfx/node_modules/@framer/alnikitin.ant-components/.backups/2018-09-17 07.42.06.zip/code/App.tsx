import { Data, Override } from "framer";
import "antd/dist/antd.css";

const data = Data({
  value: "test"
});

export const OnButtonClick: Override = () => {
  return {
    onClick: () => {
      console.log("Click!");
    }
  };
};

export const InputValue: Override = () => {
  return {
    value: data.value
  };
};

export const CheckboxCheck: Override = () => {
  return {
    onChange: () => {
      data.value = "tested";
    }
  };
};
