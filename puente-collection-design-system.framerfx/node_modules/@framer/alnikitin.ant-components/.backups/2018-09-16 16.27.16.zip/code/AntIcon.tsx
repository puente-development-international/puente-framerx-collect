import * as React from "react";
import { PropertyControls, ControlType } from "framer";
import { Icon } from "antd";

interface Props {
  type: string;
  theme: "filled" | "outlined" | "twoTone";
  size: number;
  spin: boolean;
}

export class AntIcon extends React.Component {
  // Set default properties
  static defaultProps = {
    type: "heart",
    theme: "outlined",
    size: 14,
    spin: false
  };

  // Items shown in property panel
  static propertyControls: PropertyControls = {
    type: { type: ControlType.String, title: "Type" },
    spin: { type: ControlType.Boolean, title: "Spin" },
    size: { type: ControlType.Number, title: "Size" },
    theme: {
      type: ControlType.Enum,
      options: ["filled", "outlined", "twoTone"],
      title: "Theme"
    }
  };

  render() {
    const { type, theme, spin, size } = { ...this.props };
    return <Icon style={{fontSize: `${size}px`}} type={type} theme={theme} spin={spin} />;
  }
}
