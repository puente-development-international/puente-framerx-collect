import * as React from "react";
import { PropertyControls, ControlType } from "framer";
import { Radio } from "antd";

interface Props {
  label: string;
  checked?: boolean;
  defaultChecked: boolean;
  disabled: boolean;
  
  onChange: () => void;
}

export class AntIcon extends React.Component<Props> {
  // Set default properties
  static defaultProps = {
    label: "Checkbox",
    defaultChecked: false,
    disabled: false
  };

  // Items shown in property panel
  static propertyControls: PropertyControls = {
    label: { type: ControlType.String, title: "Label" },
    defaultChecked: { type: ControlType.Boolean, title: "DefaultChecked" },
    disabled: { type: ControlType.Boolean, title: "Disabled" }
  };

  render() {
    const { label, checked, defaultChecked, disabled, onChange } = {
      ...this.props
    };
    const ifChecked = (
      <Checkbox
        checked={checked}
        defaultChecked={defaultChecked}
        disabled={disabled}
        onChange={onChange}
      >
        {label}
      </Checkbox>
    );

    if (checked) return ifChecked;

    return (
      <Checkbox
        defaultChecked={defaultChecked}
        disabled={disabled}
        onChange={onChange}
      >
        {label}
      </Checkbox>
    );
  }
}
