import * as React from "react";
import { PropertyControls, ControlType } from "framer";
import { Checkbox } from "antd";

interface Props {
  label: string;
  checked: any;
  defaultChecked: boolean;
  disabled: boolean;
  onChange: () => void;
}

export class AntCheckbox extends React.Component<Props> {
  // Set default properties
  static defaultProps = {
    width: 120,
    height: 20,
    label: "Checkbox",
    checked: "manual",
    defaultChecked: false,
    disabled: false
  };

  // Items shown in property panel
  static propertyControls: PropertyControls = {
    label: { type: ControlType.String, title: "Label" },
    checked: {
      type: ControlType.SegmentedEnum,
      options: ["manual", "true", "false"],
      title: "Checked"
    },
    disabled: { type: ControlType.Boolean, title: "Disabled" }
  };

  render() {
    const { label, checked, defaultChecked, disabled, onChange } = {
      ...this.props
    };
    const ifChecked = (
      <Checkbox
        checked={checked == "true"}
        defaultChecked={defaultChecked}
        disabled={disabled}
        onChange={onChange}
      >
        {label}
      </Checkbox>
    );

    if (checked !== "manual") return ifChecked;

    return (
      <Checkbox
        defaultChecked={defaultChecked}
        disabled={disabled}
        onChange={onChange}
      >
        {label}
      </Checkbox>
    );
  }
}
