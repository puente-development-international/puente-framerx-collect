import * as React from "react";
import { PropertyControls, ControlType } from "framer";

// Define type of property
interface Props {
  text: string;
  href: string;
}

export class AntLink extends React.Component<Props> {
  // Set default properties
  static defaultProps = {
    text: "Link",
    href: "https://"
  };

  // Items shown in property panel
  static propertyControls: PropertyControls = {
    text: { type: ControlType.String, title: "Text" },
    href: { type: ControlType.String, title: "URL" },
  };

  render() {
    return <a href={this.props.href}>{this.props.text}</a>;
  }
}
