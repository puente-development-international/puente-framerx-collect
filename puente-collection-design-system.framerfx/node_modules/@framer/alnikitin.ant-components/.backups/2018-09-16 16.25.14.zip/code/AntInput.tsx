import * as React from "react";
import { PropertyControls, ControlType } from "framer";
import { Input } from "antd";

interface Props {
  id: string;
  size: "default" | "small" | "large";
  addonBefore: string|ReactNode;
  addonAfter: string|ReactNode;
  defaultValue: string;
  value: string;
  placeholder: string;
  prefix: string;
  suffix: string;
  type: "text" | "email" | "password" | "tel" | "url";
  textarea: boolean;
  rows: number;
  disabled: boolean;
  autosize: boolean;
  onPressEnter: void;
}

export class AntInput extends React.Component {
  // Set default properties
  static defaultProps = {
    id: "",
    size: "default",
    addonBefore: "",
    addonAfter: "",
    defaultValue: "",
    value: "",
    placeholder: "",
    prefix: "",
    suffix: "",
    type: "text",
    textarea: false,
    rows: 4,
    disabled: false,
    autosize: false,
    onPressEnter: () => {}
  };

  // Items shown in property panel
  static propertyControls: PropertyControls = {
    textarea: { type: ControlType.Boolean, title: "Teaxtarea" },
    disabled: { type: ControlType.Boolean, title: "Disabled" },
    rows: {
      type: ControlType.Number,
      title: "Rows",
      hidden(props) {
        return props.textarea === false;
      }
    },
    prefix: {
      type: ControlType.String,
      title: "Prefix",
      hidden(props) {
        return props.textarea === true;
      }
    },
    suffix: {
      type: ControlType.String,
      title: "Suffix",
      hidden(props) {
        return props.textarea === true;
      }
    },
    addonBefore: {
      type: ControlType.String,
      title: "addonBefore",
      hidden(props) {
        return props.textarea === true;
      }
    },
    addonAfter: {
      type: ControlType.String,
      title: "addonAfter",
      hidden(props) {
        return props.textarea === true;
      }
    },
    placeholder: { type: ControlType.String, title: "Placeholder" },
    value: { type: ControlType.String, title: "Value" },
    type: {
      type: ControlType.Enum,
      options: ["text", "email", "password", "tel", "url"],
      title: "Type",
      hidden(props) {
        return props.textarea === true;
      }
    },
    size: {
      type: ControlType.SegmentedEnum,
      options: ["default", "small", "large"],
      title: "Size",
      hidden(props) {
        return props.textarea === true;
      }
    },
    id: { type: ControlType.String, title: "id" }
  };

  render() {
    const {
      textarea,
      id,
      size,
      addonAfter,
      addonBefore,
      defaultValue,
      value,
      placeholder,
      prefix,
      suffix,
      type,
      disabled,
      autosize,
      rows,
      onPressEnter
    } = { ...this.props };

    const area = (
      <Input.TextArea
        id={id}
        defaultValue={defaultValue}
        value={value}
        placeholder={placeholder}
        disabled={disabled}
        autosize={autosize}
        rows={rows}
        onPressEnter={onPressEnter}
      />
    );
    const field = (
      <Input
        id={id}
        size={size}
        addonAfter={addonAfter}
        addonBefore={addonBefore}
        defaultValue={defaultValue}
        value={value}
        placeholder={placeholder}
        prefix={prefix}
        suffix={suffix}
        type={type}
        disabled={disabled}
        onPressEnter={onPressEnter}
      />
    );

    return textarea ? area : field;
  }
}
