import { Data, animate, Override, Animatable } from "framer";
import "antd/dist/antd.css";

export const OnButtonClick: Override = () => {
  onClick: () => {
    console.log("Click!");
  }
}