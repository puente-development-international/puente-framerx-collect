import { Data, animate, Override, Animatable } from "framer";
import "antd/dist/antd.css";
