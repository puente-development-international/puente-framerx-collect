import * as React from "react";
import { PropertyControls, ControlType } from "framer";
import { Radio } from "antd";

interface Props {
  label: string;
  checked: any;
  defaultChecked?: boolean;
  disabled: boolean;
  value: any;
}

export class AntRadio extends React.Component<Props> {
  // Set default properties
  static defaultProps = {
    label: "Radiobutton",
    defaultChecked: false,
    disabled: false,
    value: ""
  };

  // Items shown in property panel
  static propertyControls: PropertyControls = {
    label: { type: ControlType.String, title: "Label" },
    checked: {
      type: ControlType.SegmentedEnum,
      options: ["manual", "true", "false"],
      title: "Checked"
    },
    disabled: { type: ControlType.Boolean, title: "Disabled" },
    value: { type: ControlType.String, title: "Value" }
  };

  render() {
    const { label, checked, disabled, value, defaultChecked } = {
      ...this.props
    };

    const ifChecked = (
      <Radio
        checked={checked == "true"}
        defaultChecked={defaultChecked}
        disabled={disabled}
        value={value}
      >
        {label}
      </Radio>
    );

    if (checked !== "manual") return ifChecked;

    return (
      <Radio defaultChecked={defaultChecked} disabled={disabled} value={value}>
        {label}
      </Radio>
    );
  }
}
